var banner = new Vue({
	el: '#banner_full',
	data:{
		onlineCount: 1,
		dbCount: 2,
		selfCount: 3
	}
})
